//
//  IBPSubscriptionPlanPackage.h
//  BoltPlayUser
//
//  Created by sidky sobhy on 4/24/18.
//  Copyright © 2018 inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, IBPSubscriptionExtraPlanType) {
    IBPSubscriptionExtraPlanType_UNKNOWN = 0,
    IBPSubscriptionExtraPlanType_ADDSON = 1,
    IBPSubscriptionExtraPlanType_VOD = 2,
    IBPSubscriptionExtraPlanType_PPV = 3
};



@interface IBPSubscriptionExtraPlan : NSObject

@property (nonatomic) NSString* planId;
@property (nonatomic) NSInteger expiryTime;
@property (nonatomic) NSString* title;
@property (nonatomic) NSInteger period;
@property (nonatomic) double price;
@property (nonatomic) NSString* contentId;

@property (nonatomic) IBPSubscriptionExtraPlanType planContentType;

- (instancetype) initWithPlanId:(NSString*) planId
                     expiryTime:(NSInteger) expiryTime
                       planContentType:(IBPSubscriptionExtraPlanType)planContentType
                          title:(NSString*) title
                         period:(NSInteger) period
                          price:(double) price
                      contentId:(NSString*) contentId;

@end
