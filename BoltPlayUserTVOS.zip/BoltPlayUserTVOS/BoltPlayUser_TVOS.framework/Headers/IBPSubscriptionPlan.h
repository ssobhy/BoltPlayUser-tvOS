//
//  SubscriptionPlan.h
//  BoltPlayUser
//
//  Created by sidky sobhy on 12/25/17.
//  Copyright © 2017 inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IBPSubscriptionPlanPackage.h"

@interface IBPSubscriptionPlan : NSObject

@property (nonatomic) NSString* planId;
@property (nonatomic) NSString* hashId;
@property (nonatomic) NSString* serviceId;
@property (nonatomic) NSString* title;
@property (nonatomic) NSString* planDesc;
@property (nonatomic) NSString* offerId;
@property (nonatomic) NSInteger period;
@property (nonatomic) double price;

@property (nonatomic) BOOL isContentDefault;
@property (nonatomic) BOOL isUserDefault;


// child Packages
@property (nonatomic) NSArray<IBPSubscriptionPlanPackage*>* _Nullable packages;

- (instancetype) initWithPlanId:(NSString*) planId
                        hashId:(NSString*) hashId
                     serviceId:(NSString*) serviceId
                         title:(NSString*) title
                      planDesc:(NSString*) planDesc
                       offerId:(NSString*) offerId
                        period:(NSInteger) period
                         price:(double) price
              isContentDefault:(BOOL) isContentDefault
                  isUserDefault:(BOOL) isUserDefault
                       packages:(NSArray* _Nullable)packages ;

@end
