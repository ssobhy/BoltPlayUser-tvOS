//
//  IBPSubscriptionPlanPackage.h
//  BoltPlayUser
//
//  Created by sidky sobhy on 4/24/18.
//  Copyright © 2018 inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IBPSubscriptionPlanPackage : NSObject

@property (nonatomic) NSString* _Nonnull packageId;
@property (nonatomic) NSString* _Nonnull parentPlanId;
@property (nonatomic) NSString* _Nullable title;
@property (nonatomic) NSInteger period;
@property (nonatomic) double price;

- (instancetype _Nullable ) initWithPackageId:(NSString* _Nonnull)  packageId
                         parentPlanId:(NSString* _Nonnull)  parentPlanId
                      title:(NSString* _Nullable)  title
                         period:(NSInteger) period
                             price:(double) price;

@end
