//
//  IBPBoltPlaySubscription.h
//  BoltPlayUser
//
//  Created by sidky sobhy on 12/25/17.
//  Copyright © 2017 inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IBPSubscriptionPlan.h"
#import "IBPInvoice.h"
#import "IBPSubscriptionStatus.h"


@interface IBPBoltPlaySubscription : NSObject

-(void) getAllPlans:(NSString* _Nonnull)serviceName
         completion:(void (^_Nullable)(NSArray<IBPSubscriptionPlan*> * _Nullable plans,  NSError * _Nullable error))completionBlock;

-(void) getAllInvoices:(NSString* _Nonnull)email
                 count:(NSInteger)count
         completion:(void (^_Nullable)(NSArray<IBPInvoice*> * _Nullable invoices,  NSError * _Nullable error))completionBlock;


-(void) getNextSubscriptionPlan:(NSString* _Nonnull)email
                     completion:(void (^_Nullable)(IBPSubscriptionStatus * _Nullable subscriptionStatus,  NSError * _Nullable error))completionBlock;


-(void) getSubscriptionStateFor:(NSString* _Nonnull)email
                     completion:(void (^_Nullable)(IBPSubscriptionStatus * _Nullable subscriptionStatus,  NSError * _Nullable error))completionBlock;

-(void) setSubscriptionStateForUserId:(NSString* _Nonnull)userId
                                email:(NSString* _Nonnull)email
                                 name:(NSString* _Nonnull)name
                               planId:(NSString* _Nonnull)planId
                      paymentPlatform:(NSString* _Nonnull)paymentPlatform
                               action:(NSInteger)action
                                extra:( NSDictionary* _Nonnull )extra
                           completion:(void (^_Nullable)(IBPSubscriptionStatus * _Nullable subscriptionStatus,  NSError * _Nullable error))completionBlock;


-(void) setSubscriptionAuxiliaryForUserId:(NSString* _Nonnull)userId
                                email:(NSString* _Nonnull)email
                                 name:(NSString* _Nonnull)name
                               hashId:(NSString* _Nonnull)hashId
                            serviceId:(NSString* _Nonnull)serviceId
                      paymentPlatform:(NSString* _Nonnull)paymentPlatform
                               action:(NSInteger)action
                                extra:( NSDictionary* _Nonnull )extra
                           completion:(void (^_Nullable)(IBPSubscriptionStatus * _Nullable subscriptionStatus,  NSError * _Nullable error))completionBlock;


-(void) changeCreditCardInformationWithEmail:(NSString* _Nonnull)email
                                        name:(NSString* _Nonnull)name
                          creditCardInfoHash:(NSString* _Nonnull)hash
                                  completion:(void (^_Nullable)(NSString * _Nullable response,
                                                                NSError * _Nullable error))completionBlock;

-(void) setUserCouponCode:(NSString* _Nonnull)couponCode
         subscriptionUserId:(NSString* _Nonnull)subscriptionUserId
                   client:(NSString* _Nonnull)client
               completion:(void (^_Nullable)(NSString * _Nullable response,
                                             NSError * _Nullable error))completionBlock;

@end
