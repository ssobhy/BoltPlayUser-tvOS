//
//  IBPSubscriptionStatus.h
//  BoltPlayUser
//
//  Created by sidky sobhy on 4/25/18.
//  Copyright © 2018 inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IBPSubscriptionExtraPlan.h"


@interface IBPSubscriptionStatus : NSObject

@property (nonatomic) NSString* _Nullable planId;
@property (nonatomic) NSDate* _Nullable expiryDate;
@property (nonatomic) NSString*  _Nullable packageId;
@property (nonatomic) NSString* _Nullable paymentPlatform;
@property (nonatomic) NSString* _Nullable planType;
@property (nonatomic) NSArray<IBPSubscriptionExtraPlan*>* _Nullable subscriptionExtras;


- (instancetype _Nonnull ) initWithPlanId:(NSString*_Nullable) planId
                         expiryDate:(NSDate*_Nullable) expiryDate
                      packageId:(NSString*_Nullable) packageId
                          paymentPlatform:(NSString*_Nullable) paymentPlatform
                       planType:(NSString*_Nullable) planType
                       subscriptionExtras:(NSArray*_Nullable)subscriptionExtras;


@end
