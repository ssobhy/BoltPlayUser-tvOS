//
//  IBPInvoice.h
//  BoltPlayUser
//
//  Created by sidky sobhy on 1/23/18.
//  Copyright © 2018 inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IBPInvoice : NSObject

@property (nonatomic) NSString* planId;
@property (nonatomic) NSString* transactionId;
@property (nonatomic) double price;
@property (nonatomic) NSDate* invoiceDate;

- (instancetype) initWithPlanId:(NSString*) planId
                         transactionId:(NSString*) transactionId
                          price:(double) price
               invoiceDate:(NSDate*) invoiceDate;

+ (NSDateFormatter *)dateFormatter;

@end
