//
//  IBPBoltPlayUser.h
//  BoltPlayUser
//
//  Created by sidky sobhy on 12/11/17.
//  Copyright © 2017 inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface IBPBoltPlayUser : NSObject

-(void) signIn:(NSString* _Nonnull )userIdentifier
  userPassword:(NSString* _Nonnull)userPassword
    completion:(void (^_Nullable)(NSString * _Nullable data,  NSError * _Nullable error))completionBlock;

-(void) signUp:(NSString* _Nonnull)userIdentifier
  userPassword:(NSString* _Nonnull)userPassword
      userBlob:( NSDictionary* _Nonnull )userBlob
sendConfirmEmail:( BOOL)sendConfirmEmail
    completion:(void (^_Nullable)(NSString * _Nullable data,  NSError * _Nullable error))completionBlock;

-(void) setIdentity:(NSString* _Nonnull)userIdentifier
           userBlob:( NSDictionary* _Nonnull )userBlob
         completion:(void (^_Nullable)(NSString * _Nullable data,  NSError * _Nullable error))completionBlock;

-(void) getIdentity:(NSString* _Nonnull)userIdentifier
         completion:(void (^_Nullable)(NSString * _Nullable data,  NSError * _Nullable error))completionBlock;

-(void) validateTokenForUser:(NSString* _Nonnull )userIdentifier
                   userToken:(NSString* _Nonnull)userToken
                  completion:(void (^_Nullable)(NSString * _Nullable data,  NSError * _Nullable error))completionBlock;

@end
